# Prevent typing ocpaccess.convert.convert.convert
from convert import convert
